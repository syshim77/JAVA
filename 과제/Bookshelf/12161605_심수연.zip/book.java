// 12161605 �ɼ���

import java.util.Arrays;

public class book
{
	private String title;
	private String[] authors;
	private int page;
	private int pubYear;
	
	public book(String title, String[] authors, int page, int pubYear)	// ������
	{
		setTitle(title);
		setAuthors(authors);
		setPage(page);
		setPubYear(pubYear);
	}
	
	public String getTitle()	// title ��ȯ �Լ�
	{
		return title;
	}

	public void setTitle(String title)	// title �Է� �Լ�
	{
		this.title = title;
	}
	
	public String[] getAuthors()	// authors ��ȯ �Լ�
	{
		return authors;
	}

	public void setAuthors(String[] authors)	// authors �Է� �Լ�
	{
		this.authors = authors;
	}

	public int getPage()	// page ��ȯ �Լ�
	{
		return page;
	}

	public void setPage(int page)	// page �Է� �Լ�
	{
		this.page = page;
	}

	public int getPubYear()	// pubYear ��ȯ �Լ�
	{
		return pubYear;
	}

	public void setPubYear(int pubYear)	// pubYear �Է� �Լ�
	{
		this.pubYear = pubYear;
	}

	public String toString()	// å ����(title, authors, page, pubYear) ��ȯ �Լ�
	{
		return title + " - " + Arrays.toString(authors) + " - " + page + " pages - " + pubYear + ".";
	}
	
}
